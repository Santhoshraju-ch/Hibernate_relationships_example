package com.fh.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.fh.entities.Address;

public class Test {
public static void main(String[] args) {
	Configuration configuration=new Configuration().configure();
	
	System.out.println(configuration);
	
	SessionFactory sessionFactory=configuration.buildSessionFactory();
	
	
	System.out.println(sessionFactory);
	Session session=sessionFactory.openSession();
	
	System.out.println(session);
	
	Address address=session.get(Address.class, 2);
	
	System.out.println(address);
}
}
